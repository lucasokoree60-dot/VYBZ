const pages=['feed','upload','inbox','profile'];
function showPage(page){
  pages.forEach(p=>document.getElementById(p).classList.toggle('hidden',p!==page));
  document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
document.querySelectorAll('.like').forEach(b=>b.addEventListener('click',()=>{
  b.classList.toggle('liked');const liked=b.classList.contains('liked');
  b.firstChild.textContent=liked?'♥':'♡';b.style.color=liked?'#ff3e8a':'';
  const count=b.querySelector('span');if(count){const n=parseFloat(count.textContent);count.textContent=liked?(n+0.1).toFixed(1)+'k':(n-0.1).toFixed(1)+'k';}
}));
document.querySelectorAll('.follow-btn').forEach(b=>b.addEventListener('click',()=>{b.textContent=b.textContent==='Follow'?'Following':'Follow';}));
document.querySelectorAll('.save').forEach(b=>b.addEventListener('click',()=>{b.textContent=b.textContent==='♧'?'✓':'♧';}));
document.querySelectorAll('.profile-tabs button').forEach(b=>b.addEventListener('click',()=>{
  document.querySelectorAll('.profile-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');
}));
const file=document.getElementById('videoFile'),preview=document.getElementById('preview');
file.addEventListener('change',()=>{if(file.files[0]){preview.src=URL.createObjectURL(file.files[0]);preview.classList.remove('hidden');document.getElementById('postNote').textContent=file.files[0].name;}});
document.getElementById('postBtn').addEventListener('click',()=>{
  const note=document.getElementById('postNote');
  if(!file.files.length){note.textContent='Choose a video first.';return;}
  note.textContent='Your video is ready to preview. To publish it to everyone, VYBZ needs a backend and user accounts.';
});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
