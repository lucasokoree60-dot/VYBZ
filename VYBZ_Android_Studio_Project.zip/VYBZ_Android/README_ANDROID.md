# VYBZ Android project

This is an Android Studio project wrapping the VYBZ mobile-first prototype in a native Android WebView shell. It includes Android file-picker support so a user can select a video and preview it inside the app.

## Build an installable APK

1. Install the latest stable **Android Studio** on a computer.
2. Open this `VYBZ_Android` folder in Android Studio.
3. Allow Gradle sync. Install Android SDK Platform 35 if Android Studio prompts you.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build finishes, use the **locate** link in Android Studio. The debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. To create a release APK for distribution, use **Build → Generate Signed Bundle / APK → APK**, create and safely back up your own signing key, then build the release APK.

## Current functionality

- Home feed UI with sample posts and stories
- Like, follow and save interactions
- Video picker and local preview
- Inbox and profile mockups
- Android back navigation and app shell

## Important before public release / monetization

This build is a **front-end demo**, not yet a functioning public social network. It does not have real accounts, server-side video uploads, shared feed, live chat, creator payouts, ad serving, moderation, reporting, or admin tools. The demo posts and conversations are sample content. A backend and security/privacy work are required before inviting the public.

Do not advertise earnings or promise creator payouts until a real monetization system is implemented. Before uploading to APKPure, prepare a privacy policy and support contact, test on physical Android devices, use your own signed release key, and review APKPure's current publisher and app-content requirements.

## App identity

- Display name: VYBZ
- Application ID: `com.vybz.app`
- Version: `1.0.0`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
